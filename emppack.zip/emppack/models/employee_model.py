# -*- coding: utf-8 -*-

from odoo import api, fields, models, _

class EmployeeModel(models.Model):
    _name = 'employee.detail'
    _description = 'Employee information'
    _rec_name = 'first_name'
    
    profile_pic = fields.Binary(string="Profile pic")
    first_name = fields.Char(
        string="First name",
        required=True
        )
    last_name = fields.Char(
        string="Last name",
        required=True
        )
    
    dob =  fields.Date()
    status = fields.Selection(
        [('draft','Draft'),('interview_one','Interview one'),('interview_two','Interview two'),('hired','Hired'),('enrolled','enrolled')],string="Status"
    )
    contact_number = fields.Char(
        string="contact number",
        required=True
        )
    date_of_joining =  fields.Date()
    wages_type = fields.Selection(
            [('salary', 'Salary'),('hour','Hour')],
            string="wages type", default='salary'
        )
    Wages_or_salary = fields.Selection(
        [('wages', 'Wages'),('salary','Salary')],default='salary'
        )
    gender = fields.Selection(
        [('male','Male'), ('felame','Female')],default='male'
        )
    # hobbies = fields.Char(
    #     string="Hobbies",
    #     required=True
    #     )

# ,domain=[('is_selected', '=', False)] #used to display only selceted fields 

    hobbies = fields.Many2many('employee.hobby','rel_employee_hobby','first_name','name',string="Hobbies")
  
    job_position = fields.Many2one('employee.jobposition',string="Job Position")
    certificate = fields.One2many('employee.certificate',inverse_name="employee_id",string="certificate")
    

class JobPosition(models.Model):
    _name = 'employee.jobposition'
    _description = 'Employee Job Position'
    _rec_name = 'job_position_name'

    job_position_name = fields.Char(
        string="job_position_name",
        required=True        
    )
    sequence = fields.Integer(
        string="sequence"
    )

class Hobbies(models.Model):
    _name = 'employee.hobby'

    name = fields.Char(
        string="name",
        required=True
    )

    is_selected = fields.Integer()

class Certificate(models.Model):
    _name = 'employee.certificate'
    _rec_name = 'employee_id'
    certificate = fields.Binary(
        string="certificate"
    )
    c_type = fields.Selection([('10','10th Marksheet'),('12','12th Marksheet'),('g','Graduation certificate'), ('p','ID Card')],string="Type")
    employee_id = fields.Many2one('employee.detail',string="Employee Detail")